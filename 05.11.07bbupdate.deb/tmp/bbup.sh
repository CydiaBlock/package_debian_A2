#!/bin/sh

launchctl unload /System/Library/LaunchDaemons/com.apple.CommCenter.plist

./BBUpdaterExtreme update -f ICE2_05.11.07.fls -e ICE2_05.11.07.eep

launchctl load /System/Library/LaunchDaemons/com.apple.CommCenter.plist 