var Time24 = false ; // change to false if you are using 12h time formating

/* dont change anything below this line unless you know what you are doing :-) */

// time handling begin

function Hours() {
	var now = TimeRefresh();
	
	var hours = now[0];
	
	var zero_h_ = true ;
	if (typeof zero_h !== 'undefined') {
		zero_h_ = zero_h ;
	}

	if (Time24) {
		if (hours < 10 && zero_h_)
			hours = '0' + hours;
		return hours;
	} else {
		if (hours > 12)
			hours -= 12;
		if (hours < 10 && zero_h_) {
			hours = '0' + hours;
		}
		return hours ;	
	}
}

function Minutes() {
	var now = TimeRefresh();
	
	var minutes = now[1];

	var zero_m_ = true ;
	if (typeof zero_m !== 'undefined') {
		zero_m_ = zero_m ;
	}
	
	if (minutes < 10 && zero_m_)
		minutes = "0" + minutes;
	return minutes ;
}

var d = new Date();
function TimeRefresh () {
	d = new Date();
	
	var hours = d.getHours();
	var minutes = d.getMinutes();
	var seconds = d.getSeconds();
	
	result = new Array(3);
	result = [hours, minutes, seconds];
	
	return result;
}

function DayNumeric() {
	if (d.getDate() < 10) {
		var daynum = "0" + d.getDate();
	} else {
		var daynum = d.getDate();
	}
    return daynum;
}

function DayWord() {
    var weekday = new Array(7);
    
    weekday[0]="Sunday";
    weekday[1]="Monday";
    weekday[2]="Tuesday";
    weekday[3]="Wednesday";
    weekday[4]="Thursday";
    weekday[5]="Friday";
    weekday[6]="Saturday";
    
    return weekday[d.getDay()];
}

function Month() {
    month = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
    return month[d.getMonth()];
}

// time handling end

function update () {
	var complete_mode_ = false ;
	if (typeof complete_mode !== 'undefined') {
		complete_mode_ = complete_mode ;
	}
	if (complete_mode_) {
		// DATE COMPLETE :
		document.getElementById("dateComplete").innerHTML = DayNumeric() ;
		document.getElementById("dayComplete").innerHTML = DayWord() ;
		document.getElementById("monthComplete").innerHTML = Month() ;

		// TIME COMPLETE
		document.getElementById("hoursComplete").innerHTML = Hours() ;
		document.getElementById("minutesComplete").innerHTML = Minutes() ;

		updateCompleteLine() ;

	}
	else {
		// DATE SIMPLE :
		document.getElementById("dateSimple").innerHTML = DayNumeric() ;
		document.getElementById("daySimple").innerHTML = DayWord() ;
		document.getElementById("monthSimple").innerHTML = Month() ;

		// TIME SIMPLE
		document.getElementById("hoursSimple").innerHTML = Hours() ;
		document.getElementById("minutesSimple").innerHTML = Minutes() ;

		updateSimpleLine() ;
	}

	document.body.style.display = 'initial' ;

	if (typeof isCelsius !== 'undefined') {
		if (isCelsius) {

		}
	}
	

	setTimeout(update, 1000);
}

function handleOptions () {

	var hour_ = false ;
	var complete_mode_ = false ;
	var black_mode_ = false ;
	var thin_font_ = false ;
	var thicker_font_ = false ;

	if (typeof hour !== 'undefined') {
		hour_ = hour ;
	}
	if (typeof complete_mode !== 'undefined') {
		complete_mode_ = complete_mode ;
	}
	if (typeof black_mode !== 'undefined') {
		black_mode_ = black_mode ;
	}
	if (typeof thin_font !== 'undefined') {
		thin_font_ = thin_font ;
	}
	if (typeof thicker_font !== 'undefined') {
		thicker_font_ = thicker_font ;
	}

	// 24 HOUR FORMAT
	Time24 = hour_ ;

	// COMPLETE_MODE
	if (complete_mode_) {
		document.getElementById("simpleUI").innerHTML = '' ;
	}
	else {
		document.getElementById("completeUI").innerHTML = '' ;
	}

	// BLACK MODE
	if (black_mode_) {
		document.body.style.color = 'black' ;
		if (complete_mode_)
			document.getElementById("lineComplete").src = './Images/line-black.png' ;
		else
			document.getElementById("lineSimple").src = './Images/line-black.png' ;
	}

	// THICKER FONT
	if (thicker_font_) {
		document.body.style.fontFamily = 'Colfax-Light' ;
	}

	// THIN FONT
	if (thin_font_) {
		var font = document.body.style.fontFamily ;
		if (font.length < 1)
			font = "Colfax-Thin" ;
		if (complete_mode_)
			document.getElementById("completeTime").style.fontFamily = font ;
		else
			document.getElementById("simpleTime").style.fontFamily = font ;
	}
	
}

function updateSimpleLine () {
	var time = document.getElementById("simpleTime") ;
	var twidth = time.offsetWidth ;
	var line = document.getElementById("lineSimple") ;
	var lineWidth = twidth - 60 ;
	line.style.width = lineWidth + "px" ;
}

function updateCompleteLine () {
	var time = document.getElementById("completeTime") ;
	var twidth = time.offsetWidth ;
	var line = document.getElementById("lineComplete") ;
	var lineWidth = twidth + 60 ;
	line.style.width = lineWidth + "px" ;
}

function getWOEID() {

	var woeid = "2388327" ;

	var xmlhttp = new XMLHttpRequest();
	xmlhttp.open("GET","file:///var/mobile/Documents/widgetweather.xml",false);
	xmlhttp.send(null);
	woeid = xmlhttp.responseXML.getElementsByTagName("woeid")[0].childNodes[0].nodeValue ;

	return woeid ;
}