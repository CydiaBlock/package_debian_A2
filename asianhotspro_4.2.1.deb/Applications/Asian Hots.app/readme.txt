prefix is used

relative directory to upload new images
database select prefix_db
