/***

CONFIGURATION
Change these as I've explained next to them. Don't be a foo'

**/

// Don't ask, just go to yahoo weather, search for your town and check the url for the last digits, for example: http://.../london-44418 so 44418 is london
var YWCode = '1236594';

//Update the weather every __ minutes...
var updateWeatherEvery = 15;

//Set to 'c' or 'f' for celsius or farenheit
var tempUnit = 'c';

//Show a pretty little weather image representing the current condition? true or false only
var showWeatherImage = true;

//Set to true to use numeric values on clock instead of roman numerals, i.e. 12, 3, 6 and 9 instead of XII, III, VI and IX
var numericClock = false;

//Sets the colour of the second hand and temperature
//ONLY: red, orange, green, blue
var colour = 'red';

//Set the text inside the clock, default is 'iPhone', use <br> for more lines; e.g. This is line 1<br>This is line 2. Other HTML allowed if you're a 1337 h4x0r.
var clockText = 'Cydia.vn';



/**************************************

End of configuration - this is all important
Please don't break it and blame it on me

Use as you wish, steal as you please
	
**************************************/


var lastUpdatedWeather = 0;

//Update the clock with the current time
function updateTime(){
	var days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
	var now = new Date();
	var day = days[now.getDay()];
	var date = now.getDate() < 10 ? '0'+now.getDate() : now.getDate();
	var h = now.getHours();
	var m = now.getMinutes();
	var s = now.getSeconds();
	var throughHour = findThrough('hour', m);
	var throughMin = findThrough('min', s);
	
	document.getElementById('day').innerHTML = day;
	document.getElementById('date').innerHTML = date;
	
	var hRotate = (h*30)+throughHour;
	var mRotate = (m*6)+throughMin;
	var sRotate = s*6;
	
	document.getElementById('hourHand').style.webkitTransform = "rotate("+hRotate+"deg)";
	document.getElementById('minuteHand').style.webkitTransform = "rotate("+mRotate+"deg)";
	document.getElementById('secondHand').style.webkitTransform = "rotate("+sRotate+"deg)";
	
	if ((lastUpdatedWeather == 0) || (now.getTime() - lastUpdatedWeather >= updateWeatherEvery))
	{
		fetchWeatherData();
		lastUpdatedWeather = now.getTime();
	}
}

//Update the weather information
function updateWeather(wtrObj){
	if (wtrObj.error)
	{
		document.getElementById('location').innerHTML = "Unknown";
		document.getElementById('temp').innerHTML = "NA";
		if (showWeatherImage)
			document.getElementById('weatherIcon').setAttribute('src', 'images/weather/'+wtrImages[48]+'.png');
	}
	else
	{
		document.getElementById('location').innerHTML = wtrObj.city;
		document.getElementById('temp').innerHTML = wtrObj.temp+"&deg;";
		if (showWeatherImage)
			document.getElementById('weatherIcon').setAttribute('src', 'images/weather/'+wtrImages[wtrObj.image]+'.png');
	}
}

//Finds how far through the hour/minute we are
function findThrough(unit, val){
	if (val == 0) return 0;
	var working = (1/(60/val))*100;
	if (unit == 'hour') return Math.floor((6/100)*working)*6;
	return Math.floor((6/100)*working);
}

//Change to numeric clock
function setNumeric(){
	document.getElementById('top').innerHTML = '12';
	document.getElementById('right').innerHTML = '3';
	document.getElementById('bottom').innerHTML = '6';
	document.getElementById('left').innerHTML = '9';
}

//Called on body load, initialises theme
function init(){
	updateWeatherEvery *= 60*1000;
	if (colour.toLowerCase() != 'red' && colour.toLowerCase() != 'orange' && colour.toLowerCase() != 'green' && colour.toLowerCase() != 'blue') colour = 'red';
	document.getElementById('text').innerHTML = clockText;
	document.getElementById('temp').setAttribute("class", colour);
	document.getElementById('secondHand').setAttribute("class", colour);
	if (numericClock) setNumeric();
	if (showWeatherImage) document.getElementById('weatherIcon').style.display = 'block';
	updateTime();
	setInterval("updateTime()", 1000);
}
