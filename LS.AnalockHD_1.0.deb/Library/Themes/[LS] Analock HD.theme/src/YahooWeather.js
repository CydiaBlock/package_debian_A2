var wtrImages = [
	"tstorm3",		//0 	tornado
	"tstorm3",		//1 	tropical storm
	"tstorm3",		//2 	hurricane
	"tstorm3",		//3 	severe thunderstorms
	"tstorm2",		//4 	thunderstorms
	"sleet",		//5 	mixed rain and snow
	"sleet",		//6 	mixed rain and sleet
	"sleet",		//7 	mixed snow and sleet
	"sleet",		//8 	freezing drizzle
	"light_rain",	//9 	drizzle
	"sleet",		//10 	freezing rain
	"shower3",		//11 	showers
	"shower3",		//12 	showers
	"snow1",		//13 	snow flurries
	"snow2",		//14 	light snow showers
	"snow4",		//15 	blowing snow
	"snow5",		//16 	snow
	"hail",			//17 	hail
	"sleet",		//18 	sleet
	"mist",			//19 	dust
	"fog",			//20 	foggy
	"fog",			//21 	haze
	"fog",			//22 	smoky
	"cloudy1",		//23 	blustery
	"cloudy1",		//24 	windy
	"overcast",		//25 	cold
	"cloudy5",		//26 	cloudy
	"cloudy4_night",//27 	mostly cloudy (night)
	"cloudy4",		//28 	mostly cloudy (day)
	"cloudy1_night",//29 	partly cloudy (night)
	"cloudy1",		//30 	partly cloudy (day)
	"sunny_night",	//31 	clear (night)
	"sunny",		//32 	sunny
	"mist_night",	//33 	fair (night)
	"mist",			//34 	fair (day)
	"hail",			//35 	mixed rain and hail
	"sunny",		//36 	hot
	"tstorm1",		//37 	isolated thunderstorms
	"tstorm2",		//38 	scattered thunderstorms
	"tstorm2",		//39 	scattered thunderstorms
	"tstorm2",		//40 	scattered showers
	"snow5",		//41 	heavy snow
	"snow3",		//42 	scattered snow showers
	"snow5",		//43 	heavy snow
	"cloudy1",		//44 	partly cloudy
	"tstorm1",		//45 	thundershowers
	"snow2",		//46 	snow showers
	"tstorm1",		//47 	isolated thundershowers
	"dunno",		//3200  (48)	not available
];

//Searches XML document for nodes
function searchForChild(element, nodeName)
{
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling)
		if (child.nodeName == nodeName)
			return child;		
	return null;
}

//Sends an XMLHTTPRequest - snazzy huh
function fetchWeatherData (){

	var url="http://weather.yahooapis.com/forecastrss?w="+YWCode+"&u="+tempUnit;
	
	var xml_request = new XMLHttpRequest();
	xml_request.onload = function() {xml_responded(xml_request);}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET", url+"&antiCache="+Math.floor(Math.random()*1001));
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null);	
	
	return xml_request;
}

//We actually got a response from Yahoo!
function xml_responded (request){
	if (request.responseXML)
	{
	 	var wtrObj = {error:false};
		var channel = searchForChild(searchForChild(request.responseXML, "rss"), "channel");
		wtrObj.city = searchForChild(channel, "yweather:location").getAttribute("city");
		
		var condition = searchForChild(searchForChild(channel, "item"), "yweather:condition");
		wtrObj.temp = condition.getAttribute("temp");
		wtrObj.image = condition.getAttribute("code");
		
		updateWeather(wtrObj);
	}
	else
	{
		updateWeather({error:true});
	}
}