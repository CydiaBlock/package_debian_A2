// ..........................................
// RefinedHD Weather Tvo_Modded.theme
// Version 1
// ..........................................
// Based on code referenced in several weather enabled themes
//
// This is designed for Wallpaper use
//
// Please see the readme.txt file for Change History and other information
//
// Modded from the original WeatherWidget.theme by Tim Sharp
// Originally Produced by Adam Watkins (http://www.stupidpupil.co.uk)
// ..........................................

// Examples for the "locale" variable:
//  '20603' - US zip codes...
//  'Defiance, Ohio'
//  'Moscow, Russia'
//  'London, UK'
//
//Change Your City / Location
var locale = "VMXX0006"  // "95014" seemed like a fine Default - Cupertino, CA 

// Temperature Readings
// Set to 'false' if you prefer Farenheit
// Set to 'true' if you prefer Celsius
var isCelsius = true //true|false

// Use 'Real Feel' temperatures where possible, taking into account Wind Chill, Humidity etc.
var useRealFeel = false //true|false


// Choose a Stylesheet for the Widget.  You have a few choices:
//
//tvoTwist     (Default)
//bubble
//iconOnly
//myopia
//originalBubble
//tick

var stylesheetWall = 'myopia'


// Choose an "Image Set" for the weather graphics. Several from various weather themes have been included.

var iconSetWall = 'tick' //'iWeather'|'HTC'|'katra'|'tick'|'klear'|'minis'



// ..........................................


// Please endeavour to set this to a sensible value if you really must change it...

var updateInterval = 1440 //Minutes

// ..........................................
