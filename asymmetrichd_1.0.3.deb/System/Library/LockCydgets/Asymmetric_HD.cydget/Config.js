/*

Configuration here

by ImLemonPartying

*/

	// AFTER MAKING ANY CHANGES HERE, RESPRING YOUR DEVICE!
	

 	// 12 Hour Code (change to 0 for 24Hour) 
	// 0 = 24, 1 = 12
	var my12_hour = 1;


	// AFTER MAKING ANY CHANGES HERE, RESPRING YOUR DEVICE!

/*

Hugs 'n kisses,
ImLemonPartying

*/
