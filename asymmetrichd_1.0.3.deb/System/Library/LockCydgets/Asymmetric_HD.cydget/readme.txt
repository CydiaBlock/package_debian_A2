To change to 24-hour time, 
open Config.js
and follow the instructions!

Hugs 'n kisses,
ImLemonPartying
