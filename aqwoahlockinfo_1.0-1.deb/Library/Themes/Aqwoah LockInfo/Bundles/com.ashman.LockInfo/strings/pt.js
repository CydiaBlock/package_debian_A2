var string_weather = "Meteorologia";
var string_mail = "Correio";
var string_calendar = "Calendario";
var string_calls = "Chamadas perdidas";
var string_voicemail = "Correio de voz";
var string_sms = "SMS";

var string_noSubject = "(nada)";
var string_from = "";
var string_noResponse = "Sem resposta";
var string_noCity = "Cidade invalida";

var string_loadMore = "Ver mais";

// Time/date (see http://php.net/date for format syntax)
var format_time = "G:i"; //translates to e.g. 9:26 am (for 24 hr format use "G:i"
var clock_format_time = "G:i";

// Format for date
var format_date = "l, j F";

// Short format for date
var format_date_short = "d/M/y";

// Format for date and time
var format_date_time = format_date+" "+format_time;

// Short format for date and time
var format_date_time_short = format_date_short+" "+format_time;

var string_am = "am";
var string_pm = "pm";

// Don't forget the space after the prefix and before the suffix!
var string_begins_prefix = "Comeca ";
var string_begins_suffix = "";
var string_began_prefix = "Comecou ";
var string_began_suffix = "";
var string_ends_prefix = "Acaba ";
var string_ends_suffix = "";

var future_prefix = "em ";
var future_suffix = "";
var past_prefix = "";
var past_suffix = " atras";

var string_today = "Hoje";
var string_tonight = "Hoje � Noite";
var string_yesterday = "Ontem";
var string_tomorrow = "Amanh�";

var string_now = "Agora";
var string_justNow = "Mesmo agora";
var string_JustUpdated = "Recentemente";

var string_birthday = "Aniversario";

var periods = [
	"segundo",
	"minuto",
	"hora",
	"dia",
	"semana",
	"mes",
	"ano"
];

var periods_plural = [
	"segundos",
	"minutos",
	"horas",
	"dias",
	"semanas",
	"meses",
	"anos"
];

var periods_short = [
	"s",
	"m",
	"h",
	"d",
	"w",
	"m",
	"y"
];

var shortMonths = [
	"Jan",
	"Fev",
	"Mar",
	"Abr",
	"Mai",
	"Jun",
	"Jul",
	"Ago",
	"Set",
	"Out",
	"Nov",
	"Dez"
];

var longMonths = [
	"Janeiro",
	"Fevereiro",
	"Marco",
	"Abril",
	"Maio",
	"Junho",
	"Julho",
	"Agosto",
	"Setembro",
	"Outubro",
	"Novembro",
	"Dezembro"
];

var shortDays = [
	"Dom",
	"Seg",
	"Ter",
	"Qua",
	"Qui",
	"Sex",
	"Sab"
];

var longDays = [
	"Domingo",
	"Segunda-feira",
	"Ter�a-feira",
	"Quarta-feira",
	"Quinta-feira",
	"Sexta-feira",
	"Sabado"
];

var weatherText = [
	"",
	"Ceu limpo",
	"Solarengo",
	"Ceu pouco nublado",
	"Parcialmente nublado",
	"Sol com neblina",
	"Ceu muito nublado",
	"Nublado",
	"Nublado e sombrio",
	"",
	"",
	"Nevoeiro",
	"Aguaceiros",
	"Aguaceiros",
	"Aguaceiros",
	"Trovoada",
	"Trovoada",
	"Trovoada",
	"Chuva",
	"Vento/chuva breve",
	"Vento/chuva breve",
	"Vento/chuva breve",
	"Neve",
	"Neve",
	"Gelo",
	"Granizo",
	"Granizo",
	"",
	"",
	"Frio/chuva/granizo",
	"Quente",
	"Frio",
	"Ventoso",
	"Limpo",
	"Ceu pouco nublado",
	"Parcialmente nublado",
	"Parcialmente nublado",
	"Neblina",
	"Muito nublado",
	"Aguaceiros",
	"Aguaceiros",
	"Trovoada",
	"Trovoada",
	"Vento/chuva breve",
	"Vento/chuva breve"
];

