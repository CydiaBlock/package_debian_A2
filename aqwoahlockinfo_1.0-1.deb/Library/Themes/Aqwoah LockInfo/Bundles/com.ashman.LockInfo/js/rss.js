function rssSwipeLeft() {
  rssSourceIndex += 1;
  if (rssSourceIndex > rssSources.length-1) { rssSourceIndex = 0; }
  rssBuildHTML();
}

function rssSwipeRight() {
  rssSourceIndex = rssSourceIndex - 1;
  if (rssSourceIndex < 0 ) { rssSourceIndex = rssSources.length-1; }
  rssBuildHTML();
}

function rssToggleDesc() {
  rssDescShow = !rssDescShow;
  rssBuildHTML();
}

function rssBuildHTML() {
  // Title
  var rssTitleNew = "<div class='rss_desc' onclick='rssToggleDesc();'></div><img class='icon' src='Icon Sets/none.png'>";
  rssTitleNew += "<span class='rssHeaderTitle' onclick='rssSwipeLeft();'>"+rssTitles[rssSourceIndex]+"</span>";
  document.getElementById("rssTitle").innerHTML = rssTitleNew;

  // content
  var intSourceDesc = 0;
  if (rssDescShow) { intSourceDesc = rssDescChars[rssSourceIndex]; }
  var rssContentNew = "<span class='sub'><iframe src='html/RSS.html?"+rssSourceIndex+","+intSourceDesc+","+rssItems;

  rssContentNew += "' frameborder='0' width='100%' height='"+ rssFrameSize +"' scrolling='no' allowTransparency='true'></iframe></span>";
  document.getElementById("rssContent").innerHTML = rssContentNew;
}
