var weatherTempCity = [];
var weatherTempLo = [];
var weatherTempHi = [];

var postals = {length:0};
var xmlReq = new XMLHttpRequest();
var launchReq = new XMLHttpRequest();
var headID = document.getElementsByTagName("head")[0];
var scriptNode = document.createElement('script');
var weatherRetries = 0;
var lastWeatherUpdate;
var dayCodes = {
	"SUN":0,
	"MON":1,
	"TUE":2,
	"WED":3,
	"THU":4,
	"FRI":5,
	"SAT":6
};
scriptNode.type = 'text/javascript';
scriptNode.src = 'weatherSources/'+weatherSource+'.js';
headID.appendChild(scriptNode);

function updateWeather(){
	window.clearTimeout(document.getElementById("weather_timestamp").timer);
	document.getElementById("weather_timestamp").innerHTML = "...";
	if(locales && locales.length){
		for(var i = 0; i < locales.length; i++){
			validateWeatherLocation(escape(locales[i]).replace(/^%u/g, "%"), setPostal, i);
		}
	}
}

function convertTemp(num){
	if(isCelsius){
		return Math.round((num - 32) * 5 / 9);
	}else{
		return num;
	}
}

function setPostal(obj){
	if(!obj.error){
		if(obj.cities.length > 0){
			postals[obj.id] = escape(obj.cities[0].zip).replace(/^%u/g, "%");
			postals.length++;
			weatherDIV.className = "";
			if(postals.length == locales.length){
				weatherRefresherTemp();
			}
		}else{
			if(lastWeatherUpdate){
				relativeTime(weatherDIV, "weather_timestamp", lastWeatherUpdate, false, true, string_JustUpdated);
			}else{
				document.getElementById("weather_timestamp").innerHTML = "";
			}
			document.getElementById("weather_"+obj.id+"_icon").src = "Icon Sets/"+iconSet+"/dunno"+iconExt;
			document.getElementById("weather_"+obj.id+"_desc").innerHTML = "&ndash; "+string_noCity;
			collapsed["weather_"+obj.id] = false;
			toggleSection(["weather_"+obj.id, true]);
			if(obj.id == 0){
				document.getElementById("weather_icon").src = "Icon Sets/"+iconSet+"/dunno"+iconExt;
				document.getElementById("weather_desc").innerHTML = "&ndash; "+string_noCity;
			}
			if(collapsed["Weather"]){
				collapsed["Weather"] = false;
				toggleSection([weatherDIV, true]);
			}
		}
	}else{
		window.clearTimeout(weatherDIV.timer);
		if(lastWeatherUpdate){
			relativeTime(weatherDIV, "weather_timestamp", lastWeatherUpdate, false, true, string_JustUpdated);
		}else{
			document.getElementById("weather_timestamp").innerHTML = "";
		}
		document.getElementById("weather_"+obj.id+"_icon").src = "Icon Sets/"+iconSet+"/dunno"+iconExt;
		document.getElementById("weather_"+obj.id+"_desc").innerHTML = "&ndash; "+obj.errorString;
		toggleSection(["weather_"+obj.id+"_forecast", true]);
		if(obj.id == 0){
			document.getElementById("weather_icon").src = "Icon Sets/"+iconSet+"/dunno"+iconExt;
			document.getElementById("weather_desc").innerHTML = "&ndash; "+obj.errorString;
		}
		if(collapsed["Weather"]){
			collapsed["Weather"] = false;
			toggleSection([weatherDIV, true]);
		}
	}
}

function dealWithWeather(obj){
	window.clearTimeout(weatherDIV.timer);

	if(!obj.error){
		weatherRetries = 0;
		lastWeatherUpdate = new Date();
		var city = obj.city+': ';
		var desc = " &ndash; "+weatherText[obj.icon];
		if(useRealFeel){
			tempValue = convertTemp(obj.realFeel);
		}else{
			tempValue = convertTemp(obj.temp);
		}

		weatherTempCity[obj.id] = tempValue;
		var temp = tempValue+"&deg;";
		var icon = "Icon Sets/"+iconSet+"/"+MiniIcons[obj.icon]+iconExt;

		if(locales.length > 1 || !mainHeaderWeather){
			removeClass(document.getElementById("weather_"+obj.id), "empty");
			document.getElementById("weather_"+obj.id+"_city").innerHTML = displayCityNames ? city : '';
			document.getElementById("weather_"+obj.id+"_desc").innerHTML = desc;
			document.getElementById("weather_"+obj.id+"_temp").innerHTML = temp;
			document.getElementById("weather_"+obj.id+"_icon").src = "Icon Sets/none.png";	// icon;
		}
		if(obj.id == 0){
			relativeTime(weatherDIV, "weather_timestamp", lastWeatherUpdate, false, true, string_JustUpdated);
			if(mainHeaderWeather){
				document.getElementById("weather_city").innerHTML = displayMainCityName ? city : '';
				document.getElementById("weather_desc").innerHTML = desc;
				document.getElementById("weather_temp").innerHTML = temp;
				document.getElementById("weather_icon").src = "Icon Sets/none.png";	// icon;
			}
		}

		var c = Math.min(obj.forecast.length, weatherDayLimit);
		var html = "<table><tbody><tr>";
		var i = 0;

		html += "<td width='"+Math.round(100/c)+"%'>";
		html += "<span class='sub1'>"+string_today+":</span><br>";
		html += "<img src=\"Icon Sets/"+iconSet+"/"+MiniIcons[obj.forecast[i].icon]+iconExt+"\"/><br>";
		html += "<span class='sub1'>"+ weatherShowTime(obj.sunrise)+"</span><br>";
		html += "<span class='sub1'>"+ weatherShowTime(obj.sunset)+"</span>";

		// Modified: Moon Phase ------------------------------

		weatherTempHi[obj.id] = "" + obj.forecast[i].hi;
		weatherTempLo[obj.id] = "" + obj.forecast[i].lo;

		html += "<td width='"+Math.round(100/c)+"%' class='rightborder' >";
		html += "<span class='sub1' id='intTemp"+[obj.id]+"-"+i+"_hi'>"+convertTemp(obj.forecast[i].hi)+"&deg; &ndash; </span>";
		html += "<span class='sub4' id='intTemp"+[obj.id]+"-"+i+"_lo'>"+convertTemp(obj.forecast[i].lo)+"&deg;</span>";
		html += "<img src=\"Icon Sets/moon/"+obj.moonphase+iconExt+"\"/><br>";
		html += "<span class='sub1'>"+ weatherShowTime(obj.moonrise)+"</span><br>";
		html += "<span class='sub1'>"+ weatherShowTime(obj.moonset)+"</span>";
		html += "</td>";

		for(i = 1; i < c; i++){
			weatherTempHi[obj.id] += ","+obj.forecast[i].hi;
			weatherTempLo[obj.id] += ","+obj.forecast[i].lo;

			html += "<td width='"+Math.round(100/c)+"%'>";
			html += "<span class='sub1'>"+shortDays[dayCodes[obj.forecast[i].daycode]]+"</span><br>";
			html += "<img src=\"Icon Sets/"+iconSet+"/"+MiniIcons[obj.forecast[i].icon]+iconExt+"\"/><br>";
			html += "<span class='sub1' id='intTemp"+[obj.id]+"-"+i+"_hi'>"+convertTemp(obj.forecast[i].hi)+"&deg;</span><br>";
			html += "<span class='sub4'id='intTemp"+[obj.id]+"-"+i+"_lo'>"+convertTemp(obj.forecast[i].lo)+"&deg;</span>";
		}

		html += "</tr></tbody></table>";
		var forecastDIV = document.getElementById("weather_"+obj.id+"_forecast");
		forecastDIV.innerHTML = html;
		forecastDIV.style.display = weatherDIV.lastChild.style.display = "block";
		collapsed["weather_"+obj.id+"_forecast"] = !collapsed["weather_"+obj.id+"_forecast"];
		toggleSection([forecastDIV, true]);

		if(postals.length == locales.length && !collapsed["Weather"]){
			collapsed["Weather"] = true;
			toggleSection([weatherDIV, true]);
		}

		if(locales.length > 1 && weatherCycleCities == 0){
			subsectionCollapsed("weather_"+obj.id, "Weather", !obj.id);
			if(collapsed["weather_"+obj.id]){
				collapsed["weather_"+obj.id] = false;
				toggleSection(["weather_"+obj.id, true]);
			}
		}
		if(collapsed["Weather"]){
			collapsed["Weather"] = false;
			toggleSection([weatherDIV, true]);
		}
		if(weatherUpdateInterval){
			weatherDIV.timer = window.setTimeout(weatherRefresherTemp, 60000*weatherUpdateInterval);
		}
	}else if(weatherRetryInterval && (!weatherRetriesMax || weatherRetries <= weatherRetriesMax)){
		relativeTime(weatherDIV, "weather_timestamp", lastWeatherUpdate, false, true, string_JustUpdated);
		weatherDIV.timer = window.setTimeout(weatherRefresherTemp, 60000*weatherRetryInterval);
	}else{
		relativeTime(weatherDIV, "weather_timestamp", lastWeatherUpdate, false, true, string_JustUpdated);
	}
}

function weatherRefresherTemp(){
	if(postals.length != locales.length){
		updateWeather()
		return;
	}
	window.clearTimeout(document.getElementById("weather_timestamp").timer);
	if(weatherRetriesMax && weatherRetries){
		document.getElementById("weather_timestamp").innerHTML = weatherRetries+'/'+weatherRetriesMax+"...";
	}else{
		document.getElementById("weather_timestamp").innerHTML = "...";
	}
	weatherRetries++;
	for(var i = 0; i < postals.length; i++){
		fetchWeatherData(dealWithWeather, postals[i], i);
	}
}

function weatherSwipeLeft() {
  if (weatherCycleCities == 0) { return; };		// user does not want city cycling
  if (locales.length == 1) { return; } 			// don't do anything, we only have 1 city

  weatherLocalesIndex += 1;
  if (weatherLocalesIndex > locales.length-1) { weatherLocalesIndex = 0; }
  weatherRebuildDiv();
}

function weatherSwipeRight() {
  if (weatherCycleCities == 0) { return; };		// user does not want city cycling
  if (locales.length == 1) { return; } 			// don't do anything, we only have 1 city

  weatherLocalesIndex = weatherLocalesIndex - 1;
  if (weatherLocalesIndex < 0) { weatherLocalesIndex = locales.length-1; }
  weatherRebuildDiv();
}

function weatherRebuildDiv() {
  for(var i = 0; i < locales.length; i++){
    if (i == weatherLocalesIndex) {
      document.getElementById("weather_"+ i).style.display = 'block';
      if (collapsed["weather_"+i]) { toggleSection(["weather_"+i, false]); }
    } else {
      document.getElementById("weather_"+ i).style.display = 'none';
    }
  }
}

function weatherChangeTemp() {
  blnDisableCollapseOnce = true;

  var tempHi = [];
  var tempLo = [];
  isCelsius = !isCelsius;

  for(var i = 0; i < locales.length; i++){
    document.getElementById("weather_"+i+"_temp").innerHTML = convertTemp(parseInt(weatherTempCity[i])) + "&deg;";	

    tempHi = weatherTempHi[i].split(',');
    tempLo = weatherTempLo[i].split(',');
    for(var j = 0; j < weatherDayLimit; j++){
      document.getElementById("intTemp"+i+"-"+j+"_hi").innerHTML = convertTemp(parseInt(tempHi[j])) + "&deg;" + (j==0 ? ' &ndash; ' : '');
      document.getElementById("intTemp"+i+"-"+j+"_lo").innerHTML = convertTemp(parseInt(tempLo[j])) + "&deg;";
    }
  }
}

function weatherShowTime(tmTime) {
  var strTime = "--:--";
  var tmNewTime = new Date("1/1/2000 " + tmTime);
  if (!isNaN(tmNewTime)) { strTime = tmNewTime.format(format_time); }
  return strTime;
}

