var locale = 12772249; // The location WOEID, see README.txt for more information
var isCelsius = false;
var enableBG = true; // Enable semi-transparent background or not. Recommended for bright/light coloured wallpapers.
var updateInterval = 1800; // In seconds, time between a new update is fetched
var failedInterval = 300; // In seconds, time between another attempt is made for an update when the previous one fails
var ampm_format = false; // Whether to have in 12 hour format(true) or 24 hour format(false)
var show_ampm = false; // Whether to show AM/PM in time display(true) or not(false)