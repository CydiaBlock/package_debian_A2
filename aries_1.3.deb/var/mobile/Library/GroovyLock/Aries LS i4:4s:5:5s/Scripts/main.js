var updateWeatherEvery = updateInterval*60*1000;
var xmldata = false;
var postal;
var refreshLocationTimer;
var updateTimer = 0;
var zip;

	var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	var months=["January","February","March","April","May","June","July","August","September","October","November","December"];


function ForecastDayNames(day) {
switch (day) {
    case "Sun": { return days[0]; }
    case "Mon": { return days[1]; }
    case "Tue": { return days[2]; }
    case "Wed": { return days[3]; }
    case "Thu": { return days[4]; }
    case "Fri": { return days[5]; }
    case "Sat": { return days[6]; }
    case "Today": { return "Today"; }
    case "Tonight": { return "Tonight"; }
	}
}

function updateClock() {
var currentTime = new Date();
var currentHours = currentTime.getHours();
var currentMinutes = currentTime.getMinutes();
var currentMinutes1 = currentTime.getMinutes();
var currentMinutesunit = currentTime.getMinutes ( );
var currentSeconds = currentTime.getSeconds();
var currentDate = currentTime.getDate() < 10 ? '0' + currentTime.getDate() : currentTime.getDate();
timeOfDay = ( currentHours < 12 ) ? "am" : "pm";

   var currentHours_name_array = new Array ("12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12")
   var currentMinutes_name_array = new Array ("0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "1", "1", "1", "1", "1", "1", "1", "1", "1", "1", "2", "2", "2", "2", "2", "2", "2", "2", "2", "2", "3", "3", "3", "3", "3", "3", "3", "3", "3", "3", "4", "4", "4", "4", "4", "4", "4", "4", "4", "4", "5", "5", "5", "5", "5", "5", "5", "5", "5", "5", "")
   var currentMinutesunit_name_array = new Array ("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "1", "2", "3", "4", "5", "6", "7", "8", "9", "", "1", "2", "3", "4", "5", "6", "7", "8", "9", "", "1", "2", "3", "4", "5", "6", "7", "8", "9", "", "1", "2", "3", "4", "5", "6", "7", "8", "9", "")

if (Clock == "24h") {
	currentHours = ( currentHours < 10 ? "" : "" ) + currentHours;
	currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	currentTimeString = currentHours + currentMinutes + currentMinutesunit;
	currentTimeString1 = currentHours + ":" + currentMinutes1;
	document.getElementById("ampm").innerHTML = timeOfDay;
	} else {
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	currentMinutes1= ( currentMinutes1< 10 ? "0" : "" ) + currentMinutes1;
	currentTimeString1 = currentHours + ":" + currentMinutes1;
	document.getElementById("ampm").innerHTML = timeOfDay;
}

document.getElementById("hour").innerHTML = currentHours_name_array[currentHours];
document.getElementById("minute").innerHTML = currentMinutes_name_array[currentMinutes];
document.getElementById("minutesunit").innerHTML = currentMinutesunit_name_array[currentMinutesunit];

document.getElementById("weekday").innerHTML = days[currentTime.getDay()];
document.getElementById("date").innerHTML = currentDate;
document.getElementById("month").innerHTML = months[currentTime.getMonth()];

if (currentTime.getTime() - updateTimer >= updateWeatherEvery) {
	if (updateTimer == 0) {
		if (gps == true) { UpdateLocation(); } else { validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal); }
		} else {
		weatherRefresherTemp(zip);
		}
	updateTimer = currentTime.getTime();
	}
}

function init(){
document.getElementById("cityname").innerHTML = "Wait Dude!!";

updateClock();
setInterval("updateClock();", 1000);
}

function setPostal(obj){
	if (obj.error == false){
		if(obj.cities.length > 0) {
			postal = escape(obj.cities[0].zip).replace(/^%u/g, "%")
			conver2eid();
			}
			else
			{
			document.getElementById("cityname").innerHTML="Locale ?!";
			}
		}
		else
		{
		document.getElementById("cityname").innerHTML="Locale ?!";
		setTimeout('validateWeatherLocation(escape(locale).replace(/^%u/g, "%"), setPostal)', Math.round(1000*60*5));
		}
}

function weatherRefresherTemp(zip){
	fetchWeatherData(dealWithWeather, zip);
}

function validateWeatherLocation (location, callback) {
	var obj = {error:false, errorString:null, cities: new Array};
	obj.cities[0] = {zip: location};
	callback (obj);
}

function dealWithWeather(obj){
	if (obj.error == false){
	       document.getElementById("cityname").innerHTML=obj.city;
		document.getElementById("temp").innerHTML = obj.temp + "&#176;";
		document.getElementById("weathericon").src="Images/Custom/"+ obj.icon +".jpg";
		document.getElementById("desc").innerHTML=obj.description;

		document.getElementById("Day1").innerHTML=ForecastDayNames(obj.Day1);
		document.getElementById("Day1Icon").src="Images/"+IconSet+"/"+obj.Day1Code+".png";
		document.getElementById("Day1HiLo").innerHTML=obj.Day1Lo+ "&#176;/ "+obj.Day1Hi+ "&#176;";
		document.getElementById("Day2").innerHTML=ForecastDayNames(obj.Day2);
		document.getElementById("Day2Icon").src="Images/"+IconSet+"/"+obj.Day2Code+".png";
		document.getElementById("Day2HiLo").innerHTML=obj.Day2Lo+ "&#176;/ "+obj.Day2Hi+ "&#176;";
		document.getElementById("Day3").innerHTML=ForecastDayNames(obj.Day3);
		document.getElementById("Day3Icon").src="Images/"+IconSet+"/"+obj.Day3Code+".png";
		document.getElementById("Day3HiLo").innerHTML=obj.Day3Lo+ "&#176;/ "+obj.Day3Hi+ "&#176;";
                document.getElementById("Day4").innerHTML=ForecastDayNames(obj.Day4);
		document.getElementById("Day4Icon").src="Images/"+IconSet+"/"+obj.Day4Code+".png";
		document.getElementById("Day4HiLo").innerHTML=obj.Day4Lo+ "&#176;/ "+obj.Day4Hi+ "&#176;";
	}
	else
	{
	document.getElementById("cityname").innerHTML = "Internet ?!";
	}
}

function findChild (element, nodeName) {
	var child;
	for (child = element.firstChild; child != null; child = child.nextSibling)
	{
		if (child.nodeName == nodeName)
			return child;
	}
	return null;
}

function conver2eid () {
		var url = "http://weather.yahooapis.com/forecastrss?w="+postal+"&u=f";
		$.get(url, function(data) {
		zip = $(data).find('guid').text().split('_')[0];
		weatherRefresherTemp(zip);
		});
}

function fetchWeatherData (callback, zip) {
	var url="http://xml.weather.yahoo.com/forecastrss/"+zip+"&u="+tempUnit+"&d=5.xml";
	var xml_request = new XMLHttpRequest();
	var requestTimer = setTimeout(function() {
	xml_request.abort();
	if (xmldata == false) { callback ({error:true}); } else {
	document.getElementById("coordinates").className = "TextColorRed"; 
	document.getElementById("coordinates").innerHTML = "[Offline]"; }
    }, 10000);
	xml_request.onload = function(e) {
	clearTimeout(requestTimer);
	xml_loaded(e, xml_request, callback);
	}
	xml_request.overrideMimeType("text/xml");
	xml_request.open("GET", url);
	xml_request.setRequestHeader("Cache-Control", "no-cache");
	xml_request.send(null);
	return xml_request;
}

function xml_loaded (event, request, callback) {
	if (request.responseXML)
	{
		var obj = {error:false, errorString:null};
		xmldata = true;
		var effectiveRoot = findChild(findChild(request.responseXML, "rss"), "channel");
		if (gps == false) {
		if (city == "") { obj.city = findChild(effectiveRoot, "yweather:location").getAttribute("city"); }
		else { obj.city = city }
		} else { obj.city = city; }
		obj.humidity = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("humidity");
		obj.windunit = findChild(effectiveRoot, "yweather:units").getAttribute("speed");		
		obj.winddir = findChild(effectiveRoot, "yweather:wind").getAttribute("direction");
		obj.windspeed = findChild(effectiveRoot, "yweather:wind").getAttribute("speed");	
		obj.visibility = findChild(effectiveRoot, "yweather:atmosphere").getAttribute("visibility");	
		obj.visibilityunit = findChild(effectiveRoot, "yweather:units").getAttribute("distance");
		obj.sunrise = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunrise");
		obj.sunset = findChild(effectiveRoot, "yweather:astronomy").getAttribute("sunset");
		obj.chill = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");
		obj.realFeel = findChild(effectiveRoot, "yweather:wind").getAttribute("chill");
		var conditionTag = findChild(findChild(effectiveRoot, "item"), "yweather:condition");
		obj.temp = conditionTag.getAttribute("temp");
		obj.icon = conditionTag.getAttribute("code");
		obj.description = conditionTag.getAttribute("text");
		var forecast = findChild(findChild(effectiveRoot, "item"), "yweather:forecast");
		obj.todaylow = forecast.getAttribute("low");
		obj.todayhigh = forecast.getAttribute("high");
		if (obj.description == "Unknown") {
			obj.description = forecast.getAttribute("text");
			obj.icon = forecast.getAttribute("code");
		}
		if (obj.icon == 3200) obj.icon = 48;
		
		obj.Day1 = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("day");
		obj.Day1Hi = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("high");
		obj.Day1Lo = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("low");
		obj.Day1Code = request.responseXML.getElementsByTagName("forecast")[1].getAttribute("code");
		
		obj.Day2 = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("day");
		obj.Day2Hi = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("high");
		obj.Day2Lo = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("low");
		obj.Day2Code = request.responseXML.getElementsByTagName("forecast")[2].getAttribute("code");
		
		obj.Day3 = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("day");
		obj.Day3Hi = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("high");
		obj.Day3Lo = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("low");
		obj.Day3Code = request.responseXML.getElementsByTagName("forecast")[3].getAttribute("code");

                obj.Day4 = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("day");
		obj.Day4Hi = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("high");
		obj.Day4Lo = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("low");
		obj.Day4Code = request.responseXML.getElementsByTagName("forecast")[4].getAttribute("code");

		callback (obj); 
	}
	else
	{
		callback ({error:true, errorString:"XML request failed. no responseXML"});
	}
}

