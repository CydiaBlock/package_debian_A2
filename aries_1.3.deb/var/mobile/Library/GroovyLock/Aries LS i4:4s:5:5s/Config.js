/*
Configuration here !
Code by CostoTech
*/

var Clock = "12h";		  // Choose 12h or 24h
var updateInterval = 30;       // in Minutes